/* Каркас сайта: шапка, меню, появление блоков, FAQ, нить, липкая кнопка,
   cookie, формы. Без внешних библиотек. */

(function () {
  'use strict';

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* --- 1. Шапка: линия при отрыве от верха --- */

  var header = document.querySelector('.site-header');
  if (header) {
    var markStuck = function () {
      header.setAttribute('data-stuck', window.scrollY > 8 ? 'true' : 'false');
    };
    markStuck();
    window.addEventListener('scroll', markStuck, { passive: true });
  }

  /* --- 2. Мобильное меню --- */

  var toggle = document.querySelector('.menu-toggle');
  var mobileNav = document.querySelector('.mobile-nav');

  if (toggle && mobileNav) {
    toggle.addEventListener('click', function () {
      var open = mobileNav.getAttribute('data-open') === 'true';
      mobileNav.setAttribute('data-open', open ? 'false' : 'true');
      toggle.setAttribute('aria-expanded', open ? 'false' : 'true');
    });

    mobileNav.addEventListener('click', function (e) {
      if (e.target.closest('a')) {
        mobileNav.setAttribute('data-open', 'false');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mobileNav.getAttribute('data-open') === 'true') {
        mobileNav.setAttribute('data-open', 'false');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
      }
    });
  }

  /* --- 3. Появление блоков: один раз, только transform и opacity --- */

  var revealables = document.querySelectorAll('.reveal');

  if (!revealables.length) {
    /* ничего */
  } else if (reduced || !('IntersectionObserver' in window)) {
    revealables.forEach(function (el) { el.setAttribute('data-shown', 'true'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.setAttribute('data-shown', 'true');
        io.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -12% 0px', threshold: 0.05 });

    revealables.forEach(function (el) { io.observe(el); });
  }

  /* --- 4. FAQ --- */

  document.querySelectorAll('.faq__q').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var open = btn.getAttribute('aria-expanded') === 'true';
      var answer = document.getElementById(btn.getAttribute('aria-controls'));
      btn.setAttribute('aria-expanded', open ? 'false' : 'true');
      if (answer) answer.setAttribute('data-open', open ? 'false' : 'true');
    });
  });

  /* --- 5. Нить: прочерчивается один раз при загрузке --- */

  document.querySelectorAll('.thread').forEach(function (svg) {
    var path = svg.querySelector('path');
    if (!path) return;

    var length = 1200;
    try { length = Math.ceil(path.getTotalLength()) || 1200; } catch (e) { /* кривой path */ }
    path.style.setProperty('--len', length);

    if (reduced) return;

    /* Рисуем, когда секция вошла в поле — иначе пользователь пропускает жест */
    if (!('IntersectionObserver' in window)) {
      svg.setAttribute('data-draw', 'true');
      return;
    }
    var tio = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        svg.setAttribute('data-draw', 'true');
        tio.unobserve(svg);
      });
    }, { threshold: 0.15 });
    tio.observe(svg);
  });

  /* --- 6. Липкая кнопка на мобильном --- */

  var sticky = document.querySelector('.sticky-cta');
  if (sticky && document.body.getAttribute('data-form-page') !== 'true') {
    var target = document.querySelector(sticky.getAttribute('data-anchor') || '.hero');
    var update = function () {
      var past = target ? target.getBoundingClientRect().bottom < 0 : window.scrollY > 400;
      sticky.setAttribute('data-show', past ? 'true' : 'false');
    };
    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
  }

  /* --- 7. Cookie --- */

  var cookie = document.querySelector('.cookie');
  if (cookie) {
    var KEY = 'da:cookie-ack';
    var settled = false;
    try { settled = localStorage.getItem(KEY) === '1'; } catch (e) { settled = false; }
    if (!settled) {
      cookie.setAttribute('data-show', 'true');
      cookie.querySelectorAll('[data-cookie-close]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          cookie.setAttribute('data-show', 'false');
          try { localStorage.setItem(KEY, '1'); } catch (e) { /* приватный режим */ }
        });
      });
    }
  }

  /* --- 8. UTM и рекламные метки --- */

  var ATTR_KEY = 'da:attrib';

  function captureAttribution() {
    var params = new URLSearchParams(window.location.search);
    var keep = {};
    ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'yclid'].forEach(function (k) {
      if (params.get(k)) keep[k] = params.get(k);
    });
    if (!Object.keys(keep).length) return;

    var stored = {};
    try { stored = JSON.parse(sessionStorage.getItem(ATTR_KEY) || '{}'); } catch (e) { stored = {}; }
    var next = Object.assign({}, stored, keep, { page: window.location.pathname });
    try { sessionStorage.setItem(ATTR_KEY, JSON.stringify(next)); } catch (e) { /* */ }
  }

  function fillHiddenFields(form) {
    var stored = {};
    try { stored = JSON.parse(sessionStorage.getItem(ATTR_KEY) || '{}'); } catch (e) { return; }

    Object.keys(stored).forEach(function (k) {
      var input = form.querySelector('[name="' + k + '"]');
      if (input && !input.value) input.value = stored[k];
    });

    var page = form.querySelector('[name="page"]');
    if (page && !page.value) page.value = window.location.pathname;

    var fromQuiz = sessionStorage.getItem('da:quiz');
    if (fromQuiz) {
      try {
        var q = JSON.parse(fromQuiz);
        ['audience', 'tariff'].forEach(function (k) {
          var input = form.querySelector('[name="' + k + '"]');
          if (input && !input.value && q[k]) input.value = q[k];
        });
      } catch (e) { /* */ }
    }
  }

  captureAttribution();

  /* --- 9. Формы --- */

  var ENDPOINT = ''; /* ЗАМЕНИТЬ: адрес обработчика форм или CRM-webhook */

  function validate(form) {
    var bad = null;
    form.querySelectorAll('[data-required]').forEach(function (input) {
      var field = input.closest('.field') || input.closest('.consent');
      var value = input.type === 'checkbox' ? input.checked : input.value.trim();
      var ok = !!value;

      if (input.type === 'email') ok = ok && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
      if (input.type === 'tel') ok = ok && value.replace(/\D/g, '').length >= 10;

      if (field) field.setAttribute('data-invalid', ok ? 'false' : 'true');
      input.setAttribute('aria-invalid', ok ? 'false' : 'true');
      if (!ok && !bad) bad = input;
    });
    return bad;
  }

  function status(form, state, text) {
    var box = form.querySelector('.form__status');
    if (!box) return;
    box.setAttribute('data-state', state);
    box.textContent = text;
    box.setAttribute('role', state === 'error' ? 'alert' : 'status');
  }

  document.querySelectorAll('form.form').forEach(function (form) {
    fillHiddenFields(form);

    form.querySelectorAll('[data-required]').forEach(function (input) {
      input.addEventListener('input', function () {
        var field = input.closest('.field') || input.closest('.consent');
        if (field && field.getAttribute('data-invalid') === 'true') validate(form);
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      var firstBad = validate(form);
      if (firstBad) {
        status(form, 'error', 'Проверьте отмеченные поля — без них заявку не отправить.');
        firstBad.focus();
        return;
      }

      var data = {};
      new FormData(form).forEach(function (v, k) {
        if (data[k]) { data[k] = [].concat(data[k], v); } else { data[k] = v; }
      });
      data.sent_at = new Date().toISOString();

      form.setAttribute('data-busy', 'true');
      status(form, 'loading', 'Отправляю…');

      if (!ENDPOINT) {
        /* Бэкенд не подключён. Заявка не уходит: говорим об этом честно,
           данные не выбрасываем — их видно в консоли для отладки. */
        console.warn('[direct-ad] ENDPOINT не задан — заявка НЕ отправлена', data);
        form.setAttribute('data-busy', 'false');
        status(form, 'error',
          'Форма ещё не подключена к почте или CRM: заявка никуда не ушла. '
          + 'Напишите напрямую — Telegram или hello@direct-ad.ru.');
        return;
      }

      fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
        .then(function (r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          form.reset();
          form.setAttribute('data-busy', 'false');
          status(form, 'sent', form.getAttribute('data-sent') || 'Заявка отправлена. Отвечу в рабочее время в течение часа.');
        })
        .catch(function (err) {
          form.setAttribute('data-busy', 'false');
          status(form, 'error', 'Не отправилось: ' + err.message + '. Попробуйте ещё раз или напишите в Telegram.');
        });
    });
  });
})();
